/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package game;
import java.io.FileNotFoundException;


/**
 *
 * @author hajiaga
 */

//public class Main {
//
//    public static void main(String[] args) { // main method should be defined
//        try {
//            Capitaly board = new Capitaly("nese.txt");
//            board.play();
//        } catch (InvalidInputException ex) {
//            System.out.println("Invalid input!");
//            System.exit(-1);
//        }
//    }
//}